# messages

Autoware-specific message and interface definitions.

www.autoware.org
